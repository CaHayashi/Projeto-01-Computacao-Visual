#include "processing.h"
#include <SDL3/SDL.h>
#include <math.h>

// ================= HISTOGRAMA =================
void compute_histogram(SDL_Surface *img, int histogram[256]) {
    for (int i = 0; i < 256; i++) histogram[i] = 0;

    SDL_LockSurface(img);

    Uint32 *pixels = (Uint32*)img->pixels;
    Uint8 r, g, b;

    const SDL_PixelFormatDetails *fmt = SDL_GetPixelFormatDetails(img->format);

    int total = img->w * img->h;

    for (int i = 0; i < total; i++) {
        SDL_GetRGB(pixels[i], fmt, NULL, &r, &g, &b);
        histogram[r]++;
    }

    SDL_UnlockSurface(img);
}

// ================= MÉTRICAS =================
float compute_mean(int histogram[256], int total_pixels) {
    long sum = 0;

    for (int i = 0; i < 256; i++) {
        sum += i * histogram[i];
    }

    return (float)sum / total_pixels;
}

float compute_stddev(int histogram[256], int total_pixels, float mean) {
    float variance = 0.0;

    for (int i = 0; i < 256; i++) {
        float diff = i - mean;
        variance += diff * diff * histogram[i];
    }

    variance /= total_pixels;

    return sqrt(variance);
}

const char* classify_brightness(float mean) {
    if (mean < 85) return "Escura";
    else if (mean < 170) return "Media";
    else return "Clara";
}

const char* classify_contrast(float stddev) {
    if (stddev < 50) return "Baixo";
    else if (stddev < 100) return "Medio";
    else return "Alto";
}

// ================= HISTOGRAMA IMAGEM =================
SDL_Surface* create_histogram_image(int histogram[256]) {
    int width = 256;
    int height = 200;

    SDL_Surface *img = SDL_CreateSurface(width, height, SDL_PIXELFORMAT_RGBA32);
    if (!img) return NULL;

    SDL_LockSurface(img);

    Uint8 *base = (Uint8*)img->pixels;
    int pitch = img->pitch;

    const SDL_PixelFormatDetails *fmt = SDL_GetPixelFormatDetails(img->format);

    Uint32 white = SDL_MapRGB(fmt, NULL, 255, 255, 255);

    for (int y = 0; y < height; y++) {
        Uint32 *row = (Uint32*)(base + y * pitch);
        for (int x = 0; x < width; x++) {
            row[x] = white;
        }
    }

    int max = 0;
    for (int i = 0; i < 256; i++) {
        if (histogram[i] > max) max = histogram[i];
    }

    if (max == 0) max = 1;

    for (int x = 0; x < 256; x++) {
        int bar_height = (histogram[x] * height) / max;

        for (int y = height - 1; y >= height - bar_height; y--) {
            Uint32 *row = (Uint32*)(base + y * pitch);
            row[x] = SDL_MapRGB(fmt, NULL, 0, 0, 0);
        }
    }

    SDL_UnlockSurface(img);
    return img;
}

// ================= EQUALIZAÇÃO =================
SDL_Surface* equalize_image(SDL_Surface *gray) {

    int histogram[256] = {0};
    compute_histogram(gray, histogram);

    int total = gray->w * gray->h;

    float cdf[256] = {0};
    cdf[0] = histogram[0];

    for (int i = 1; i < 256; i++) {
        cdf[i] = cdf[i-1] + histogram[i];
    }

    for (int i = 0; i < 256; i++) {
        cdf[i] /= total;
    }

    SDL_Surface *eq = SDL_CreateSurface(gray->w, gray->h, SDL_PIXELFORMAT_RGBA32);

    SDL_LockSurface(gray);
    SDL_LockSurface(eq);

    Uint8 *in = (Uint8*)gray->pixels;
    Uint8 *out = (Uint8*)eq->pixels;

    for (int i = 0; i < gray->w * gray->h; i++) {
        Uint8 val = in[i * 4];
        Uint8 new_val = (Uint8)(cdf[val] * 255.0f);

        out[i*4 + 0] = new_val;
        out[i*4 + 1] = new_val;
        out[i*4 + 2] = new_val;
        out[i*4 + 3] = 255;
    }

    SDL_UnlockSurface(gray);
    SDL_UnlockSurface(eq);

    return eq;
}
// Importando as bibliotecas necessários e os .h (cabeçalhos)

// Bibliotecas
#include <SDL3_image/SDL_image.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

// Cabeçalhos (.h)
#include "image.h"
#include "processing.h"


// protótipo
void draw_swap_icon(SDL_Renderer *r, float cx, float cy, float time, int hover);

// 🔵 círculo preenchido
void draw_filled_circle(SDL_Renderer *r, float cx, float cy, float radius) {
    for (int w = -radius; w <= radius; w++) {
        for (int h = -radius; h <= radius; h++) {
            if (w*w + h*h <= radius*radius) {
                SDL_RenderPoint(r, cx + w, cy + h);
            }
        }
    }
}

// 🔁 ícone animado
void draw_swap_icon(SDL_Renderer *r, float cx, float cy, float time, int hover) {

    SDL_SetRenderDrawColor(r, 255, 255, 255, 255);

    float radius = 8;
    float speed = hover ? 2.0f : 0.5f;
    float angle_offset = time * speed;

    for (int i = 45; i < 405; i++) {
        float rad = (i * 3.14159f / 180.0f) + angle_offset;
        int x = cx + cos(rad) * radius;
        int y = cy + sin(rad) * radius;
        SDL_RenderPoint(r, x, y);
    }
}

// 🎨 botão
void draw_button_pro(SDL_Renderer *r, float cx, float cy, float base_radius, int hover, int active) {

    float time = SDL_GetTicks() / 1000.0f;
    float scale = hover ? 1.1f : (1.0f + 0.05f * sin(time * 2));
    float radius = base_radius * scale;

    // sombra
    SDL_SetRenderDrawColor(r, 0, 0, 0, 80);
    draw_filled_circle(r, cx + 4, cy + 4, radius);

    // cor do estado
    if (active) {
        SDL_SetRenderDrawColor(r, 0, 0, 180, 255);
    } else if (hover) {
        SDL_SetRenderDrawColor(r, 100, 100, 255, 255);
    } else {
        SDL_SetRenderDrawColor(r, 0, 0, 255, 255);
    }

    draw_filled_circle(r, cx, cy, radius);

    draw_swap_icon(r, cx, cy, time, hover);
}

// 📝 texto
void draw_text(SDL_Renderer *r, TTF_Font *font, const char *text, int x, int y, SDL_Color color) {

    SDL_Surface *surf = TTF_RenderText_Blended(
        font,
        text,
        strlen(text),
        color
    );

    SDL_Texture *tex = SDL_CreateTextureFromSurface(r, surf);

    SDL_FRect dst = {x, y, surf->w, surf->h};
    SDL_RenderTexture(r, tex, NULL, &dst);

    SDL_DestroyTexture(tex);
    SDL_DestroySurface(surf);
}

int main(int argc, char *argv[]) {

    if (argc < 2) {
        printf("Uso: %s <imagem>\n", argv[0]);
        return 1;
    }

    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();

    TTF_Font *font = TTF_OpenFont("font/Arial_Narrow.ttf", 16);

    SDL_Surface *img = load_image(argv[1]);
    if (!img) {
        SDL_Quit();
        return 1;
    }

    SDL_Surface *gray;

    if (is_grayscale(img)) {
        gray = img;
    } else {
        gray = convert_to_grayscale(img);
        SDL_DestroySurface(img);
    }

    SDL_Surface *original_gray = gray;
    SDL_Surface *equalized = NULL;
    int is_equalized = 0;

    int histogram[256];
    compute_histogram(gray, histogram);

    SDL_Surface *hist_img = create_histogram_image(histogram);

    // 🪟 janela principal
    SDL_Window *main_window = SDL_CreateWindow("Imagem", gray->w, gray->h, 0);
    // SDL_SetWindowPosition(main_window, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED);

    SDL_Renderer *main_renderer = SDL_CreateRenderer(main_window, NULL);

    SDL_Surface *tmp = SDL_ConvertSurface(gray, SDL_PIXELFORMAT_RGBA32);
    SDL_Texture *main_texture = SDL_CreateTextureFromSurface(main_renderer, tmp);
    SDL_DestroySurface(tmp);

    // 🪟 janela secundária
    SDL_Window *sec_window = SDL_CreateWindow("Histograma", 400, 300, 0);
    SDL_Renderer *sec_renderer = SDL_CreateRenderer(sec_window, NULL);

    int main_x, main_y;
    // SDL_GetWindowPosition(main_window, &main_x, &main_y);
    //SDL_SetWindowPosition(sec_window, main_x + gray->w + 10, main_y);

    // 🔥 garantir visibilidade e foco
    SDL_ShowWindow(main_window);
    SDL_ShowWindow(sec_window);
    SDL_RaiseWindow(sec_window);

    tmp = SDL_ConvertSurface(hist_img, SDL_PIXELFORMAT_RGBA32);
    SDL_Texture *hist_texture = SDL_CreateTextureFromSurface(sec_renderer, tmp);
    SDL_DestroySurface(tmp);

    float btn_x = 350;
    float btn_y = 60;
    float btn_radius = 25;

    int running = 1;
    SDL_Event event;

    while (running) {

        float mouse_x, mouse_y;
        SDL_GetMouseState(&mouse_x, &mouse_y);

        int dx = mouse_x - btn_x;
        int dy = mouse_y - btn_y;
        int hover = (dx*dx + dy*dy <= btn_radius * btn_radius);

        while (SDL_PollEvent(&event)) {

            if (event.type == SDL_EVENT_QUIT)
                running = 0;

            if (event.type == SDL_EVENT_KEY_DOWN && event.key.key == SDLK_S) {
                const char* path = "output/output_image.png";
                
                save_image(gray, path);

                SDL_ShowSimpleMessageBox(
                    SDL_MESSAGEBOX_INFORMATION,
                    "Imagem salva",
                    path,
                    NULL
                );
            }

            if (event.type == SDL_EVENT_MOUSE_BUTTON_DOWN && hover) {

                is_equalized = !is_equalized;

                if (is_equalized) {
                    if (!equalized)
                        equalized = equalize_image(original_gray);
                    gray = equalized;
                } else {
                    gray = original_gray;
                }

                SDL_DestroyTexture(main_texture);
                tmp = SDL_ConvertSurface(gray, SDL_PIXELFORMAT_RGBA32);
                main_texture = SDL_CreateTextureFromSurface(main_renderer, tmp);
                SDL_DestroySurface(tmp);

                compute_histogram(gray, histogram);

                SDL_DestroyTexture(hist_texture);
                SDL_Surface *new_hist = create_histogram_image(histogram);

                tmp = SDL_ConvertSurface(new_hist, SDL_PIXELFORMAT_RGBA32);
                hist_texture = SDL_CreateTextureFromSurface(sec_renderer, tmp);

                SDL_DestroySurface(tmp);
                SDL_DestroySurface(new_hist);
            }
        }

        // 🔥 métricas
        float mean = compute_mean(histogram, gray->w * gray->h);
        float stddev = compute_stddev(histogram, gray->w * gray->h, mean);

        char brightness_text[64];
        char contrast_text[64];

        snprintf(brightness_text, sizeof(brightness_text),
                 "Brilho: %s", classify_brightness(mean));

        snprintf(contrast_text, sizeof(contrast_text),
                 "Contraste: %s", classify_contrast(stddev));

        // render principal
        SDL_SetRenderDrawColor(main_renderer, 0, 0, 0, 255);
        SDL_RenderClear(main_renderer);
        SDL_RenderTexture(main_renderer, main_texture, NULL, NULL);
        SDL_RenderPresent(main_renderer);

        // render secundário
        SDL_SetRenderDrawColor(sec_renderer, 30, 30, 30, 255);
        SDL_RenderClear(sec_renderer);

        SDL_RenderTexture(sec_renderer, hist_texture, NULL, NULL);

        SDL_Color red = {255, 0, 0, 255};
        SDL_Color white = {255, 255, 255, 255};

        draw_text(sec_renderer, font, brightness_text, 20, 20, red);
        draw_text(sec_renderer, font, contrast_text, 20, 50, red);

        draw_button_pro(sec_renderer, btn_x, btn_y, btn_radius, hover, is_equalized);

        // 🔤 botão E / O
        if (is_equalized)
            draw_text(sec_renderer, font, "O", btn_x - 5, btn_y - 10, white);
        else
            draw_text(sec_renderer, font, "E", btn_x - 5, btn_y - 10, white);

        SDL_RenderPresent(sec_renderer);
    }

    SDL_DestroyTexture(main_texture);
    SDL_DestroyTexture(hist_texture);

    SDL_DestroyRenderer(main_renderer);
    SDL_DestroyWindow(main_window);

    SDL_DestroyRenderer(sec_renderer);
    SDL_DestroyWindow(sec_window);

    if (equalized) SDL_DestroySurface(equalized);
    SDL_DestroySurface(original_gray);

    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();

    return 0;
}
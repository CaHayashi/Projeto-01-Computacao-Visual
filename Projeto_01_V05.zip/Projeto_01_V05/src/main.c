// Bibliotecas necessárias para manipulação gráfica, texto e utilidades
#include <SDL3_image/SDL_image.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

// Cabeçalhos do projeto (funções implementadas em outros módulos)
#include "image.h"
#include "processing.h"

// Classe main.c, responsável por:
// 1 - Inicialização do sistema gráfico (SDL e TTF);
// 2 - Controle do fluxo principal do programa;
// 3 - Integração entre processamento de imagem e interface gráfica;
// 4 - Renderização da imagem e do histograma;
// 5 - Interação com o usuário (teclado e mouse);

// Protótipo da função responsável por desenhar o ícone animado do botão
void draw_swap_icon(SDL_Renderer *r, float cx, float cy, float time, int hover);

// Função implementada para DESENHAR UM CÍRCULO PREENCHIDO
// Utilizada como base para a criação do botão
void draw_filled_circle(SDL_Renderer *r, float cx, float cy, float radius) {

    // Percorre uma área quadrada ao redor do centro
    for (int w = -radius; w <= radius; w++) {
        for (int h = -radius; h <= radius; h++) {

            // Verifica se o ponto pertence ao círculo (equação do círculo)
            if (w*w + h*h <= radius*radius) {
                SDL_RenderPoint(r, cx + w, cy + h);
            }
        }
    }
}

// Função implementada para DESENHAR O ÍCONE ANIMADO do botão
// O ícone representa visualmente a ação de alternância (equalizar/original)
void draw_swap_icon(SDL_Renderer *r, float cx, float cy, float time, int hover) {

    // Define a cor branca para o ícone
    SDL_SetRenderDrawColor(r, 255, 255, 255, 255);

    float radius = 8;

    // Velocidade da animação varia conforme interação do usuário
    float speed = hover ? 2.0f : 0.5f;

    float angle_offset = time * speed;

    // Desenha pontos ao longo de uma circunferência animada
    for (int i = 45; i < 405; i++) {

        float rad = (i * 3.14159f / 180.0f) + angle_offset;

        int x = cx + cos(rad) * radius;
        int y = cy + sin(rad) * radius;

        SDL_RenderPoint(r, x, y);
    }
}

// Função implementada para DESENHAR O BOTÃO INTERATIVO
// O botão permite alternar entre imagem original e equalizada
void draw_button_pro(SDL_Renderer *r, float cx, float cy, float base_radius, int hover, int active) {

    float time = SDL_GetTicks() / 1000.0f;

    // Efeito de escala (animação)
    float scale = hover ? 1.1f : (1.0f + 0.05f * sin(time * 2));
    float radius = base_radius * scale;

    // Desenha sombra do botão
    SDL_SetRenderDrawColor(r, 0, 0, 0, 80);
    draw_filled_circle(r, cx + 4, cy + 4, radius);

    // Define cor com base no estado do botão
    if (active) {
        SDL_SetRenderDrawColor(r, 0, 0, 180, 255); // ativo
    } else if (hover) {
        SDL_SetRenderDrawColor(r, 100, 100, 255, 255); // hover
    } else {
        SDL_SetRenderDrawColor(r, 0, 0, 255, 255); // padrão
    }

    draw_filled_circle(r, cx, cy, radius);

    // Desenha o ícone animado
    draw_swap_icon(r, cx, cy, time, hover);
}

// Função implementada para DESENHAR TEXTO na tela
// Utiliza a biblioteca SDL_ttf para renderização de fontes
void draw_text(SDL_Renderer *r, TTF_Font *font, const char *text, int x, int y, SDL_Color color) {

    // Cria uma superfície contendo o texto renderizado
    SDL_Surface *surf = TTF_RenderText_Blended(
        font,
        text,
        strlen(text),
        color
    );

    // Converte a superfície em textura para renderização
    SDL_Texture *tex = SDL_CreateTextureFromSurface(r, surf);

    SDL_FRect dst = {x, y, surf->w, surf->h};

    SDL_RenderTexture(r, tex, NULL, &dst);

    // Libera memória
    SDL_DestroyTexture(tex);
    SDL_DestroySurface(surf);
}

// Função principal
int main(int argc, char *argv[]) {

    // Valida se o caminho da imagem foi passado como argumento
    if (argc < 2) {
        printf("Uso: %s <imagem>\n", argv[0]);
        return 1;
    }

    // Inicializa os módulos do SDL e TTF
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();

    // Carrega a fonte utilizada para exibição de textos
    TTF_Font *font = TTF_OpenFont("font/Arial_Narrow.ttf", 16);

    // Carregamento da imagem
    SDL_Surface *img = load_image(argv[1]);
    if (!img) {
        SDL_Quit();
        return 1;
    }

    SDL_Surface *gray;

    // Verifica se a imagem já está em grayscale
    if (is_grayscale(img)) {
        gray = img;
    } else {
        // Caso contrário, realiza a conversão
        gray = convert_to_grayscale(img);
        SDL_DestroySurface(img);
    }

    // Ponteiros para controle de estado
    SDL_Surface *original_gray = gray;
    SDL_Surface *equalized = NULL;
    int is_equalized = 0;

    // Processamento inicial
    int histogram[256];
    compute_histogram(gray, histogram);

    SDL_Surface *hist_img = create_histogram_image(histogram);

    // Renderizando as janelas (GUI)
    SDL_Window *main_window = SDL_CreateWindow("Imagem", gray->w, gray->h, 0);
    SDL_Renderer *main_renderer = SDL_CreateRenderer(main_window, NULL);

    // Converte a imagem para textura (renderização)
    SDL_Surface *tmp = SDL_ConvertSurface(gray, SDL_PIXELFORMAT_RGBA32);
    SDL_Texture *main_texture = SDL_CreateTextureFromSurface(main_renderer, tmp);
    SDL_DestroySurface(tmp);

    SDL_Window *sec_window = SDL_CreateWindow("Histograma", 400, 300, 0);
    SDL_Renderer *sec_renderer = SDL_CreateRenderer(sec_window, NULL);

    // Garante que ambas janelas apareçam corretamente
    SDL_ShowWindow(main_window);
    SDL_ShowWindow(sec_window);

    // Define a janela secundária como ativa (na frente)
    SDL_RaiseWindow(sec_window);

    tmp = SDL_ConvertSurface(hist_img, SDL_PIXELFORMAT_RGBA32);
    SDL_Texture *hist_texture = SDL_CreateTextureFromSurface(sec_renderer, tmp);
    SDL_DestroySurface(tmp);

    // Ajustes da interface
    float btn_x = 350;
    float btn_y = 60;
    float btn_radius = 25;

    int running = 1;
    SDL_Event event;

    // loop principal (Alma do funcionamento do programa)
    while (running) {

        float mouse_x, mouse_y;
        SDL_GetMouseState(&mouse_x, &mouse_y);

        // Verifica se o mouse está sobre o botão
        int dx = mouse_x - btn_x;
        int dy = mouse_y - btn_y;
        int hover = (dx*dx + dy*dy <= btn_radius * btn_radius);

        while (SDL_PollEvent(&event)) {

            // Evento de fechamento
            if (event.type == SDL_EVENT_QUIT)
                running = 0;

            // Evento de salvar imagem (tecla S)
            if (event.type == SDL_EVENT_KEY_DOWN && event.key.key == SDLK_S) {

                const char* path = "output/output_image.png";
                save_image(gray, path);

                SDL_ShowSimpleMessageBox(
                    SDL_MESSAGEBOX_INFORMATION,
                    "Imagem salva",
                    path,
                    NULL
                );
            }

            // Evento de clique no botão
            if (event.type == SDL_EVENT_MOUSE_BUTTON_DOWN && hover) {

                // Alterna estado
                is_equalized = !is_equalized;

                if (is_equalized) {
                    if (!equalized)
                        equalized = equalize_image(original_gray);
                    gray = equalized;
                } else {
                    gray = original_gray;
                }

                // Atualiza textura da imagem principal
                SDL_DestroyTexture(main_texture);
                tmp = SDL_ConvertSurface(gray, SDL_PIXELFORMAT_RGBA32);
                main_texture = SDL_CreateTextureFromSurface(main_renderer, tmp);
                SDL_DestroySurface(tmp);

                // Atualiza histograma
                compute_histogram(gray, histogram);

                SDL_DestroyTexture(hist_texture);
                SDL_Surface *new_hist = create_histogram_image(histogram);

                tmp = SDL_ConvertSurface(new_hist, SDL_PIXELFORMAT_RGBA32);
                hist_texture = SDL_CreateTextureFromSurface(sec_renderer, tmp);

                SDL_DestroySurface(tmp);
                SDL_DestroySurface(new_hist);
            }
        }

        // Métricas (Brilho e Contraste)
        float mean = compute_mean(histogram, gray->w * gray->h);
        float stddev = compute_stddev(histogram, gray->w * gray->h, mean);

        char brightness_text[64];
        char contrast_text[64];

        snprintf(brightness_text, sizeof(brightness_text),
                 "Brilho: %s", classify_brightness(mean));

        snprintf(contrast_text, sizeof(contrast_text),
                 "Contraste: %s", classify_contrast(stddev));

        // Renderização final
        // Render da imagem principal
        SDL_SetRenderDrawColor(main_renderer, 0, 0, 0, 255);
        SDL_RenderClear(main_renderer);
        SDL_RenderTexture(main_renderer, main_texture, NULL, NULL);
        SDL_RenderPresent(main_renderer);

        // Render do histograma
        SDL_SetRenderDrawColor(sec_renderer, 30, 30, 30, 255);
        SDL_RenderClear(sec_renderer);

        SDL_RenderTexture(sec_renderer, hist_texture, NULL, NULL);

        SDL_Color red = {255, 0, 0, 255};
        SDL_Color white = {255, 255, 255, 255};

        // Exibe métricas
        draw_text(sec_renderer, font, brightness_text, 20, 20, red);
        draw_text(sec_renderer, font, contrast_text, 20, 50, red);

        // Desenha botão
        draw_button_pro(sec_renderer, btn_x, btn_y, btn_radius, hover, is_equalized);

        // Exibe estado do botão (E = equalizar / O = original)
        if (is_equalized)
            draw_text(sec_renderer, font, "O", btn_x - 5, btn_y - 10, white);
        else
            draw_text(sec_renderer, font, "E", btn_x - 5, btn_y - 10, white);

        SDL_RenderPresent(sec_renderer);
    }

    // Liberando a memória
    SDL_DestroyTexture(main_texture);
    SDL_DestroyTexture(hist_texture);

    SDL_DestroyRenderer(main_renderer);
    SDL_DestroyWindow(main_window);

    SDL_DestroyRenderer(sec_renderer);
    SDL_DestroyWindow(sec_window);

    if (equalized) SDL_DestroySurface(equalized);
    SDL_DestroySurface(original_gray);

    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();

    return 0;
}
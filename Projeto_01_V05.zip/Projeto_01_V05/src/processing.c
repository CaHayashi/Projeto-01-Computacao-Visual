#include "processing.h"
#include <SDL3/SDL.h>
#include <math.h>

// Classe processing.c, responsável por:
// 1 - Realizar o cálculo do histograma da imagem (distribuição de intensidades);
// 2 - Calcular métricas estatísticas (brilho médio e contraste);
// 3 - Classificar as métricas calculadas;
// 4 - Gerar uma representação visual do histograma;
// 5 - Aplicar a técnica de equalização de histograma para melhoria de contraste.


// Função implementada para o CÁLCULO DO HISTOGRAMA da imagem.
// O histograma armazena, para cada nível de intensidade (0 a 255),
// quantas vezes aquele valor aparece na imagem.
void compute_histogram(SDL_Surface *img, int histogram[256]) {

    // Inicializa todas as posições do histograma com zero
    // Isso garante que não existam valores residuais de execuções anteriores
    for (int i = 0; i < 256; i++) histogram[i] = 0;

    // Bloqueia a superfície para acesso direto aos pixels
    SDL_LockSurface(img);

    // Ponteiro para o vetor de pixels da imagem
    // Cada posição representa um pixel no formato RGBA32
    Uint32 *pixels = (Uint32*)img->pixels;

    // Variáveis auxiliares para armazenar os valores de cor do pixel
    Uint8 r, g, b;

    // Obtém os detalhes do formato da imagem (necessário para leitura correta dos pixels)
    const SDL_PixelFormatDetails *fmt = SDL_GetPixelFormatDetails(img->format);

    // Total de pixels da imagem (largura x altura)
    int total = img->w * img->h;

    // Percorre todos os pixels da imagem
    for (int i = 0; i < total; i++) {

        // Extrai os valores RGB do pixel atual
        SDL_GetRGB(pixels[i], fmt, NULL, &r, &g, &b);

        // Como a imagem já está em grayscale, temos:
        // r = g = b, portanto basta utilizar apenas um canal
        histogram[r]++;
    }

    // Libera o acesso à superfície
    SDL_UnlockSurface(img);
}


// Função implementada para o CÁLCULO DO BRILHO da imagem.
// O brilho é definido como a média dos níveis de intensidade dos pixels.
float compute_mean(int histogram[256], int total_pixels) {

    long sum = 0;

    // Realiza a soma ponderada das intensidades
    // Cada intensidade é multiplicada pela sua frequência no histograma
    for (int i = 0; i < 256; i++) {
        sum += i * histogram[i];
    }

    // Retorna a média das intensidades (brilho médio)
    return (float)sum / total_pixels;
}


// Função implementada para o CÁLCULO DO CONTRASTE da imagem.
// O contraste é medido através do desvio padrão das intensidades,
// indicando o quanto os valores estão dispersos em relação à média.
float compute_stddev(int histogram[256], int total_pixels, float mean) {

    float variance = 0.0;

    // Calcula a variância utilizando a média previamente calculada
    for (int i = 0; i < 256; i++) {

        // Diferença entre a intensidade atual e a média
        float diff = i - mean;

        // Soma ponderada do quadrado da diferença
        variance += diff * diff * histogram[i];
    }

    // Divide pelo total de pixels para obter a variância final
    variance /= total_pixels;

    // Retorna o desvio padrão (raiz quadrada da variância)
    return sqrt(variance);
}


// Função implementada para CLASSIFICAR o brilho da imagem.
// A classificação é feita com base em faixas de intensidade média.
const char* classify_brightness(float mean) {

    // Valores baixos indicam imagem escura
    if (mean < 85) return "Escura";

    // Valores intermediários indicam brilho médio
    else if (mean < 170) return "Media";

    // Valores altos indicam imagem clara
    else return "Clara";
}


// Função implementada para CLASSIFICAR o contraste da imagem.
// O contraste é avaliado com base no desvio padrão calculado.
const char* classify_contrast(float stddev) {

    // Baixa dispersão → pouco contraste
    if (stddev < 50) return "Baixo";

    // Dispersão moderada → contraste médio
    else if (stddev < 100) return "Medio";

    // Alta dispersão → alto contraste
    else return "Alto";
}


// Função implementada para GERAR A IMAGEM DO HISTOGRAMA.
// Esta função cria uma nova superfície SDL contendo uma representação visual
// do histograma (barras verticais).
SDL_Surface* create_histogram_image(int histogram[256]) {

    int width = 256;   // Uma coluna para cada nível de intensidade
    int height = 200;  // Altura fixa para exibição

    // Cria uma nova superfície para desenhar o histograma
    SDL_Surface *img = SDL_CreateSurface(width, height, SDL_PIXELFORMAT_RGBA32);
    if (!img) return NULL;

    SDL_LockSurface(img);

    // Ponteiro base para manipulação direta dos pixels
    Uint8 *base = (Uint8*)img->pixels;
    int pitch = img->pitch;

    const SDL_PixelFormatDetails *fmt = SDL_GetPixelFormatDetails(img->format);

    // Define a cor branca (fundo)
    Uint32 white = SDL_MapRGB(fmt, NULL, 255, 255, 255);

    // Preenche todo o fundo com branco
    for (int y = 0; y < height; y++) {
        Uint32 *row = (Uint32*)(base + y * pitch);
        for (int x = 0; x < width; x++) {
            row[x] = white;
        }
    }

    // Encontra o maior valor do histograma (necessário para normalização)
    int max = 0;
    for (int i = 0; i < 256; i++) {
        if (histogram[i] > max) max = histogram[i];
    }

    // Evita divisão por zero
    if (max == 0) max = 1;

    // Desenha as barras do histograma
    for (int x = 0; x < 256; x++) {

        // Altura proporcional da barra
        int bar_height = (histogram[x] * height) / max;

        // Desenha a barra de baixo para cima
        for (int y = height - 1; y >= height - bar_height; y--) {
            Uint32 *row = (Uint32*)(base + y * pitch);
            row[x] = SDL_MapRGB(fmt, NULL, 0, 0, 0);
        }
    }

    SDL_UnlockSurface(img);
    return img;
}


// Função implementada para a EQUALIZAÇÃO DE HISTOGRAMA.
// A equalização redistribui os níveis de intensidade da imagem,
// melhorando o contraste global.
SDL_Surface* equalize_image(SDL_Surface *gray) {

    int histogram[256] = {0};

    // Calcula o histograma da imagem original
    compute_histogram(gray, histogram);

    int total = gray->w * gray->h;

    float cdf[256] = {0};

    // Calcula a Função de Distribuição Acumulada (CDF)
    cdf[0] = histogram[0];

    for (int i = 1; i < 256; i++) {
        cdf[i] = cdf[i-1] + histogram[i];
    }

    // Normaliza a CDF para o intervalo [0,1]
    for (int i = 0; i < 256; i++) {
        cdf[i] /= total;
    }

    // Cria a nova imagem equalizada
    SDL_Surface *eq = SDL_CreateSurface(gray->w, gray->h, SDL_PIXELFORMAT_RGBA32);

    SDL_LockSurface(gray);
    SDL_LockSurface(eq);

    Uint8 *in = (Uint8*)gray->pixels;
    Uint8 *out = (Uint8*)eq->pixels;

    // Aplica a transformação de equalização pixel a pixel
    for (int i = 0; i < gray->w * gray->h; i++) {

        // Obtém o valor de intensidade do pixel atual
        Uint8 val = in[i * 4];

        // Calcula o novo valor com base na CDF
        Uint8 new_val = (Uint8)(cdf[val] * 255.0f);

        // Atualiza os canais RGB do pixel na imagem de saída
        out[i*4 + 0] = new_val;
        out[i*4 + 1] = new_val;
        out[i*4 + 2] = new_val;
        out[i*4 + 3] = 255; // canal alfa
    }

    SDL_UnlockSurface(gray);
    SDL_UnlockSurface(eq);

    return eq;
}
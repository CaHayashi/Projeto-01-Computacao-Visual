#ifndef PROCESSING_H
#define PROCESSING_H

#include <SDL3/SDL.h>

// Classe processing.h, responsável pela declaração das funções implementadas em processing.c.

// Função responsável por calcular o CONTRASTE da imagem.
void compute_histogram(SDL_Surface *img, int histogram[256]);
// Função responsável por calcular o BRILHO MÉDIO da imagem
float compute_mean(int histogram[256], int total_pixels);
// Função responsável por classificar o brilho da imagem
float compute_stddev(int histogram[256], int total_pixels, float mean);
// Função responsável por gerar a imagem do histograma
SDL_Surface* create_histogram_image(int histogram[256]);
// Função responsável por aplicar a equalização de histograma.
SDL_Surface* equalize_image(SDL_Surface *gray);
// Função responsável por classificar o contraste da imagem
const char* classify_brightness(float mean);
// Função responsável por gerar uma imagem (SDL_Surface)
const char* classify_contrast(float stddev);

#endif